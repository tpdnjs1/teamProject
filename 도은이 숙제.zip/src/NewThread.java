import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class NewThread extends Thread {
    @Override
    public void run() {
        LocalDate date = LocalDate.now();
        DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalTime time = LocalTime.now();
        DateTimeFormatter formatterTime = DateTimeFormatter.ofPattern("HH:mm");


        try {
            sleep(1000);
            System.out.println(date.format(formatterDate));
            System.out.println(time.format(formatterTime));
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
